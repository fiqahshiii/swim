<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.partials.head')

</head>

<style>
    
</style>

<body>
    @include('layouts.partials.header')
    @yield('sideNav')
    @include('layouts.partials.footer-scripts')
</body>

</html>