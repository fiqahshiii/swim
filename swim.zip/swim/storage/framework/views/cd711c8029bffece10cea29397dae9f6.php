<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div id="app">

        <main class="py-4">
            <div class="container-fluid " align="center" style="padding:50px">
                <div class="row justify-content-center">
                    <div class="col-sm-6 ">
                    <img src=" <?php echo e(asset('frontend')); ?>/images/logo.png" width="200" >
                    </div>
                </div>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <div class="col-md-12 row justify-content-center">
            <div class="copyright">
                <span class="copyright ml-auto my-auto mr-2">Copyright © <?php echo e(now()->year); ?>

                    <a href="#" rel="nofollow">Flexsys Chemicals (M) Sdn. Bhd.</a>
                </span>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\swim\swim\resources\views/layouts/app.blade.php ENDPATH**/ ?>