

<?php $__env->startSection('content'); ?>
<h4>Scheduled Waste</h4>
<h6>Display Scheduled Waste</h6>
<head>
    <style>
          @media print {
    /* Add your print-specific styles here */
    /* Hide any unnecessary elements */
    .hide-on-print {
      display: none;
    }
    /* Customize the appearance of printed elements */
    .card {
      border: 1px solid #000;
      padding: 10px;
      margin-bottom: 10px;
    }
    /* Adjust the layout for printing */
    /* Add any other necessary styles */
  }
        </style>
</head>
<!-- message box if the new waste has been added -->
<?php if(session()->has('message')): ?>
<div class="alert alert-success">    
    <?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<?php $__currentLoopData = $wastelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="print-content">
<div class="card">
    <div class="card-body">
        <!-- form add waste -->
            <div class="row">
                <div class="col">
                    <div class="row">
                        <div class="col">
                        <div class="col">
                            <label>Waste Code</label>
                            <input type="text" name="wastecode" class="form-control" value="<?php echo e($data->wastecode); ?>" disabled>
                        </div>
                        </div>
                        <div class="col">
                            <label>Weight(mt)</label>
                            <input type="number" name="weight" class="form-control" value="<?php echo e($data->weight); ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <div class="col">
                            <label>Waste Description</label>
                            <input type="text" name="wastedescription" class="form-control" value="<?php echo e($data->wastedescription); ?>" disabled>
                        </div>
                        </div>
                        <div class="col">
                            <label>Disposal Site</label>
                            <input type="text" name="disposalsite" class="form-control" value="<?php echo e($data->disposalsite); ?>"disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <div class="col">
                            <label>Waste Type</label>
                            <input type="text" name="wastetype" class="form-control" value="<?php echo e($data->wastetype); ?>" disabled>
                        </div>
                        </div>
                        <div class="col">
                            <label>Type Of Packaging</label>
                            <input type="text" name="disposalsite" class="form-control" value="<?php echo e($data->packaging); ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <div class="col">
                            <label>Physical State</label>
                            <input type="text" name="disposalsite" class="form-control" value="<?php echo e($data->state); ?>" disabled>                      
                        </div>
                        </div>
                        <div class="col">
                            <label>Disposal Status</label>
                            <input type="text" name="disposalsite" class="form-control" value="<?php echo e($data->statusDisposal); ?>" disabled>

                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                            <label>Waste Generated Date</label>
                            <input type="date" name="wasteDate" class="form-control" id="txtDate" value="<?php echo e($data->wasteDate); ?>" disabled>
                        </div>
                        <div class="col">
                            <label>Person In Charge</label>
                            <input type="text" name="pic" class="form-control" placeholder="Person in Charge Name" value="<?php echo e($data->name); ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                            <label>Waste Expired Date</label>
                            <input type="date" name="expiredDate" class="form-control" id="txtDate" value="<?php echo e($data->expiredDate); ?>" disabled>
                        </div>
          
                        <div class="col">
                            <label>Transporter</label>
                            <?php $__currentLoopData = $transporterlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="text" name="transporter" class="form-control" value="<?php echo e($trans->fullname); ?>" disabled>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <label>Receiver</label>
                        <input type="text" name="companyreceiver" class="form-control" value="<?php echo e($data->companyname); ?>" disabled>
                        </div>
                        
                        <div class="col">
                           
                         </div>
                    </div>
                    <br>
                </div> 
            </div>
            <a class="btn btn-primary" id="waste" style="float: right; color:white" href="<?php echo e(route('editwaste', $data->swListID)); ?>">Edit</a>
            <a class="btn btn-primary" id="waste" style="float: right; color:white" href="<?php echo e(route('moredetails', $data->swListID)); ?>">More Details</a>

    </div>
</div><br>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript" src='https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js'></script>
<script type="text/javascript" src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/js/bootstrap.min.js'></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<!-- to preview the chosen file from computer -->
<!-- <script type="text/javascript">
    $(function() {
        $("#pdffile").change(function() {
            $("#dvPreview").html("");

            $("#dvPreview").show();
            $("#dvPreview").append("<iframe />");
            $("iframe").css({
                "height": "400px",
                "width": "450px"
            });
            var reader = new FileReader();
            reader.onload = function(e) {
                $("#dvPreview iframe").attr("src", e.target.result);
            }
            reader.readAsDataURL($(this)[0].files[0]);
        });
    });
</script> -->

<!-- to avoid user choose the past date -->
<script>
    $(function() {
        var dtToday = new Date();

        var month = dtToday.getMonth() + 1;
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if (month < 10)
            month = '0' + month.toString();
        if (day < 10)
            day = '0' + day.toString();

        var maxDate = year + '-' + month + '-' + day;
        $('#txtDate').attr('min', maxDate);
    });
</script>
<script>
  $(function() {
    $('.print').click(function() {
      window.print();
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\swim\swim\resources\views/scheduledwaste/displaywaste.blade.php ENDPATH**/ ?>