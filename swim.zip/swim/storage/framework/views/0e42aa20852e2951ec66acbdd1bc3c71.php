<h4>Alert Notification</h4>
<hr>
<p>Dear <?php echo e($data['fullname']); ?>,</p>

<p>You have been assign a scheduled waste to be disposed.</p>

<p>Any further inquires please let us know</p>

<p>Thank you. Have a nice day.</p>

<p>Sincererly,
    <br><?php echo e(Auth::user()->name); ?>

</p><?php /**PATH C:\xampp\htdocs\swim\swim\resources\views/emails/TransEmail.blade.php ENDPATH**/ ?>