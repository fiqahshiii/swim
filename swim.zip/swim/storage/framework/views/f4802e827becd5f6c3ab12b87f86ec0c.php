


<?php $__env->startSection('content'); ?>
<b><br><h4>Attendance</h4></b>
<script src="<?php echo e(asset('frontend')); ?>/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/js/dataTables.bootstrap4.js"></script>
<script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>

<script>
    // to search the appointment 
    $(document).ready(function() {
        $('#dataTable').DataTable({
            "order": [
                [0, "asc"]
            ],
            "language": {
                search: '<i class="fa fa-search" aria-hidden="true"></i>',
                searchPlaceholder: 'Search appointment'
            }
        });

        // filter appointment
        $('.dataTables_filter input[type="search"]').css({
            'width': '300px',
            'display': 'inline-block',
            'font-size': '15px',
            'font-weight': '400'
        });
    });
</script>

<!-- to display the alert message if the record has been deleted -->
<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-header pb-0">
        <div class="row">
            <div class=" <?php echo e(auth()->user()->category== 'Employee' ? 'col-lg-10 col-md-10 col-sm-10' : (request()->routeIs('attendance') ? 'col-lg-10 col-md-10 col-sm-10' : 'col-lg-12 col-md-12 col-sm-12')); ?>">
            </div>

            <?php if( auth()->user()->category== "Employee"): ?>

            <?php if(request()->routeIs('attendance')): ?>
            <?php else: ?>
            <div class="col-lg-2 col-md-2 col-sm-2" style="float: left;">
                <a class="btn btn-success" style="float: right; width:100%;" role="button" href="">
                    <i class="fa fa-cog"></i>&nbsp; -</a>
            </div>
            <?php endif; ?>

            <?php endif; ?>

        </div>
    </div>

    <div class="card-body">
        <div class="overflow-auto" style="overflow:auto;">
            <div class="table-responsive">

            <div class="col-lg-2 col-md-2 col-sm-2" style="float: left;">
                <?php if($attendList->contains('date', now()->toDateString())): ?>
                    <button class="btn btn-primary" style="float: right; width:100%; background:#2952a3;" disabled>Check-in</button>
                <?php else: ?>
                    <form id="checkInForm" method="post" action="<?php echo e(route('checkIn')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary" style="float: right; width:100%; background:#2952a3;" role="button">Check-in</button>
                    </form>
                <?php endif; ?>
            </div>


                <?php if( auth()->user()->category== "Manager" || auth()->user()->category== "Employee" || auth()->user()->category== "Admin"): ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Check-in</th>
                            <th>Check-out</th>
                        </tr>
                    </thead>

                    <?php $__currentLoopData = $attendList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr id="row<?php echo e($data->id); ?>">
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->date); ?></td>
                            <td><?php echo e($data->checkin); ?></td>
                            <td>
                                <?php if( $data->checkout == null ): ?>
                                <center><a href="<?php echo e(route('checkOut', $data->id)); ?>" class="btn btn-primary" 
                                style="width:40%; background:#2952a3;" role="button">Check-out</a></center>
                                <?php else: ?> 
                                <?php echo e($data->checkout); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>

                <?php endif; ?>
                <!-- FOR Manager TO VIEW RECORD APPOINTNMENT LIST END -->
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('frontend')); ?>/js/jquery.dataTables.js"></script>
<script>
function deleteItem(e) {
    let id = e.getAttribute('data-id');
    let name = e.getAttribute('data-name');

    const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
            confirmButton: 'btn btn-success ml-1',
            cancelButton: 'btn btn-danger mr-1'
        },
        buttonsStyling: false
    });

    swalWithBootstrapButtons.fire({
        title: 'Are you sure?',
        html: "Name: " + name + "<br> You won't be able to revert this!",
        text: "",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
    }).then((result) => {
        if (result.value) {
            if (result.isConfirmed) {

                $.ajax({
                    type: 'DELETE',
                    url: '<?php echo e(url("/deleteFile")); ?>/' + id,
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                    },
                    success: function(data) {
                        if (data.success) {
                            swalWithBootstrapButtons.fire(
                                'Deleted!',
                                'Document has been deleted.',
                                "success"
                            );

                            $("#row" + id).remove(); // you can add name div to remove
                        }


                    }
                });

            }

        } else if (
            result.dismiss === Swal.DismissReason.cancel
        ) {
            // swalWithBootstrapButtons.fire(
            //     'Cancelled',
            //     'Your imaginary file is safe :)',
            //     'error'
            // );
        }
    });

}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\swim\swim\resources\views/account/attendance.blade.php ENDPATH**/ ?>